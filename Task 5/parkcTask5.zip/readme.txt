All Xml outputs have been tested against the provided example and match.
Model construction works correctly.
Barring malicous attempts where checks are not in place (as per pdf instructions) everything appears to work correctly.