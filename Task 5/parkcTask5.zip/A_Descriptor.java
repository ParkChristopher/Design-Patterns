//Chris Park

public abstract class A_Descriptor implements I_Visitable
{
	public A_Descriptor()
	{}
}
