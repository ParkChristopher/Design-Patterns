//Chris Park

public class PowerplantNuclear extends A_Powerplant
{
	public PowerplantNuclear(String ID)
	{
		super(ID);
	}
	
	public void generate()
	{
		System.out.println("splitting atoms");
	}
}
