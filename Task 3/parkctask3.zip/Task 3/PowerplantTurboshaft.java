//Chris Park

public class PowerplantTurboshaft extends A_Powerplant
{
	public PowerplantTurboshaft(String ID)
	{
		super(ID);
	}
	
	public void generate()
	{
		System.out.println("spinning a shaft");
	}
}
