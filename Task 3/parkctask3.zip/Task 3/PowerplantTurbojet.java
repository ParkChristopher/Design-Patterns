//Chris Park

public class PowerplantTurbojet extends A_Powerplant
{
	public PowerplantTurbojet(String ID)
	{
		super(ID);
	}
	
	public void generate()
	{
		System.out.println("exhausting a jet");
	}
}
