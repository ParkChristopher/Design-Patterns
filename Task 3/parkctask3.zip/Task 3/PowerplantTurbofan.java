//Chris Park

public class PowerplantTurbofan extends A_Powerplant
{
	public PowerplantTurbofan(String ID)
	{
		super(ID);
	}
	
	public void generate()
	{
		System.out.println("bypassing lots of air");
	}
}
