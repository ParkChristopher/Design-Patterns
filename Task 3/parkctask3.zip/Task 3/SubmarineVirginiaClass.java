//Chris Park

public class SubmarineVirginiaClass extends A_VehicleSingleEngine
{
	public SubmarineVirginiaClass(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
