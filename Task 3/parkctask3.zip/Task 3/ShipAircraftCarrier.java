//Chris Park

public class ShipAircraftCarrier extends A_VehicleSingleEngine
{
	public ShipAircraftCarrier(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
