//Chris Park

public class AircraftTrainer extends A_VehicleSingleEngine
{
	public AircraftTrainer(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
