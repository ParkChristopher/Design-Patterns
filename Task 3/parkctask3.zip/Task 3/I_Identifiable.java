//Chris Park

public interface I_Identifiable
{
	public String getID();
	public String getSaltedID();
}
