//Chris Park

public class AircraftCommercialAirliner extends A_VehicleSingleEngine
{
	public AircraftCommercialAirliner(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
