//Chris Park

public class PowerplantReciprocatingGas extends A_Powerplant
{
	public PowerplantReciprocatingGas(String ID)
	{
		super(ID);
	}
	
	public void generate()
	{
		System.out.println("vroom vroom!");
	}
}
