//Chris Park

public class ShipDestroyer extends A_VehicleSingleEngine
{
	public ShipDestroyer(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
