//Chris Park

public class PowerplantReciprocatingDiesel extends A_Powerplant
{
	public PowerplantReciprocatingDiesel(String ID)
	{
		super(ID);
	}
	
	public void generate()
	{
		System.out.println("chattering away");
	}
}
