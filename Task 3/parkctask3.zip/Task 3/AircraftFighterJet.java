//Chris Park

public class AircraftFighterJet extends A_VehicleSingleEngine
{
	public AircraftFighterJet(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
