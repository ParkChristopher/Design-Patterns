//Chris Park

public class SubmarineUBoat extends A_VehicleDoubleEngine
{
	public SubmarineUBoat(String ID, A_Powerplant primaryPowerplant,
		A_Powerplant secondaryPowerplant)
	{
		super(ID, primaryPowerplant, secondaryPowerplant);
	}
}
