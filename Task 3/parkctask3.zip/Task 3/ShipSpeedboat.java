//Chris Park

public class ShipSpeedboat extends A_VehicleSingleEngine
{
	public ShipSpeedboat(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
