//Chris Park

public class ShipYacht extends A_VehicleSingleEngine
{
	public ShipYacht(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
