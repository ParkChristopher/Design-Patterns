//Chris Park

public class PowerplantGasTurbine extends A_Powerplant
{
	public PowerplantGasTurbine(String ID)
	{
		super(ID);
	}
	
	public void generate()
	{
		System.out.println("spinning a gas turbine");
	}
}
