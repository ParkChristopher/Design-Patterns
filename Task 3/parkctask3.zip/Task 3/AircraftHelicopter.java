//Chris Park

public class AircraftHelicopter extends A_VehicleSingleEngine
{
	public AircraftHelicopter(String ID, A_Powerplant powerplant)
	{
		super(ID, powerplant);
	}
}
