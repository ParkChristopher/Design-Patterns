//Chris Park

public class PowerplantElectric extends A_Powerplant
{
	public PowerplantElectric(String ID)
	{
		super(ID);
	}
	
	public void generate()
	{
		System.out.println("generating electricity");
	}
}
