//Chris Park

public abstract class A_Shape extends A_Entity
{
	public A_Shape(String ID)
	{
		super(ID);
	}
}
