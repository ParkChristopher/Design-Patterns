//Chris Park

import java.awt.Point;
import java.awt.Dimension;

public class ContainerWindow extends A_Container
{
	public ContainerWindow(String ID, Point origin, Dimension size)
	{
		super(ID, origin, size);
	}
}
