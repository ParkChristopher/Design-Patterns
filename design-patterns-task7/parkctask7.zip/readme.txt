Everything appears to be working correctly. Adding and removing words via standard add and insert/replace methods works appropriately. Single instances only are allowed in the word pool as expected (compression ratio reflects this appropriately).

Issues:

Had a slight bug to fix in the Word equals method to ensure proper comparisons, and an edge case to handle when inserting a word at the end of the Text ArrayList. These have been modified and appear to be functioning as expected now.