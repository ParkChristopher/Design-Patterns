//Chris Park

package task6.money;

public abstract class A_CurrencyCoin extends A_Currency
{
	public A_CurrencyCoin(Money money, java.lang.String description)
	{
		super(money, description);	
	}
}
