//Chris Park

package task6.money;

public class CurrencyPaperDollar_10 extends A_CurrencyPaper
{
	public CurrencyPaperDollar_10()
	{
		super(new Money(10, 0), "ten");
	}
}
