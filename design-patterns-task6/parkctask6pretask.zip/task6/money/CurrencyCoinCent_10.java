//Chris Park

package task6.money;

public class CurrencyCoinCent_10 extends A_CurrencyCoin
{
	public CurrencyCoinCent_10()
	{
		super(new Money(10), "dime");
	}
}
