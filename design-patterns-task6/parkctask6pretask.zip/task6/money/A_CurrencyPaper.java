//Chris Park

package task6.money;

public abstract class A_CurrencyPaper extends A_Currency
{
	public A_CurrencyPaper(Money money, java.lang.String description)
	{
		super(money, description);
	}
}
