//Chris Park

package task6.money;

public class CurrencyCoinCent_25 extends A_CurrencyCoin
{
	public CurrencyCoinCent_25()
	{
		super(new Money(25), "quarter");
	}
}
