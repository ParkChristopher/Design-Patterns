//Chris Park

package task6.money;

public class CurrencyCoinCent_5 extends A_CurrencyCoin
{
	public CurrencyCoinCent_5()
	{
		super(new Money(5), "nickel");
	}
}
