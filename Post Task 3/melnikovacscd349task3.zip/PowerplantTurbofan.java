//Andrey Melnikov

public class PowerplantTurbofan extends Powerplant
{
	public PowerplantTurbofan(String identifier) 
	{
		super(identifier);
	}

	@Override
	public String generate() 
	{
		return "bypassing lots of air";
	}
}
