//Andrey Melnikov

public class SubmarineUBoot extends Vehicle
{
	private Powerplant powerplantSecondary = null;
	private boolean isPrimaryPowerplantInOperation = true;
	
	public SubmarineUBoot(String identifier, Powerplant primary, Powerplant secondary)
	{
		super(identifier, primary);

		if( primary == secondary )
		{
			throw new RuntimeException("ERROR - can not have same primary and secondary powerplant for a UBoat");
		}
		
		this.isPrimaryPowerplantInOperation = true;
		this.powerplantSecondary = secondary;
		this.powerplantSecondary.setHost(this);
	}
	
	public Powerplant getPowerplantPrimary()
	{
		return super.getPowerplant();
	}
	
	public Powerplant getPowerplantSecondary()
	{
		if(null == this.powerplantSecondary)
		{
			throw new RuntimeException("no installed secondary powerplant");
		}
		
		return this.powerplantSecondary;
	}
	
	public void isPrimaryOrSecondary(boolean primary)
	{
		this.isPrimaryPowerplantInOperation = primary;
	}
	
	public boolean isPrimaryOrSecondary()
	{
		return this.isPrimaryPowerplantInOperation;
	}
	
	public void removePowerplantPrimary()
	{
		super.removePowerplant();
	}
	
	public void removePowerplantSecondary()
	{
		if(null == this.powerplantSecondary)
		{
			throw new RuntimeException("no installed secondary powerplant");
		}
		
		this.powerplantSecondary.removeHost();
		this.powerplantSecondary = null;
	}
	
	public boolean hasPowerplantPrimary()
	{
		return super.hasPowerplant();
	}
	
	public boolean hasPowerplantSecondary()
	{
		return null != this.powerplantSecondary;
	}
	
	public void installPowerplantPrimary(Powerplant powerplant)
	{
		super.installPowerplant(powerplant);
	}
	
	public void installPowerplantSecondary(Powerplant powerplant)
	{
		if(null != this.powerplantSecondary)
		{
			throw new RuntimeException("powerplant " + this.powerplantSecondary.getID() + "  already installed");
		}
		
		this.powerplantSecondary = powerplant;
		this.powerplantSecondary.setHost(this);
	}
	
	@Override
	public void move()
	{
		if( this.isPrimaryPowerplantInOperation && this.powerplant != null)
		{
			System.out.println(this.getIDSalted() + ": " + this.powerplant.generate());
		}
		else if( !this.isPrimaryPowerplantInOperation && this.powerplantSecondary != null)
		{
			System.out.println(this.getIDSalted() + ": " + this.powerplantSecondary.generate());
		}
		else
		{
			System.out.println("no powerplants");
		}
	}
}