//Andrey Melnikov

public class PowerplantReciprocatingDiesel extends Powerplant
{
	public PowerplantReciprocatingDiesel(String identifier) 
	{
		super(identifier);
	}

	@Override
	public String generate() {
		return "chattering away";
	}
}
