//Andrey Melnikov

public class IdentifierSaltManager 
{
	private int saltNumber = 0;
	private static IdentifierSaltManager instance = null;
	
	public static IdentifierSaltManager getInstance()
	{
		if( null == instance)
		{
			instance = new IdentifierSaltManager();
		}
		
		return instance;
	}
	
	private IdentifierSaltManager()
	{
		this.saltNumber = 0;
	}
	
	public String getIDSalted(String identifier)
	{
		return identifier + "#" + getSaltNext();
	}
	
	private int getSaltNext()
	{
		this.saltNumber++;
		return this.saltNumber;
	}
}