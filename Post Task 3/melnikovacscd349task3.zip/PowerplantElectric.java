//Andrey Melnikov

public class PowerplantElectric extends Powerplant
{
	public PowerplantElectric(String identifier)
	{
		super(identifier);
	}

	@Override
	public String generate() 
	{
		return "generating electricity";
	}
}
