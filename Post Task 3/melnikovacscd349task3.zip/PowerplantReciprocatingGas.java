//Andrey Melnikov

public class PowerplantReciprocatingGas extends Powerplant
{
	public PowerplantReciprocatingGas(String identifier) 
	{
		super(identifier);
	}

	@Override
	public String generate() {
		return "vroom vroom!";
	}
}
