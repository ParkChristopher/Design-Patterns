//Andrey Melnikov

public class AircraftCommercialAirliner extends Vehicle
{
	public AircraftCommercialAirliner(String identifier, Powerplant powerplant) 
	{
		super(identifier, powerplant);
	}	
}
