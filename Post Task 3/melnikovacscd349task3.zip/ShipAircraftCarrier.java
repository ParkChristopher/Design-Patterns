//Andrey Melnikov

public class ShipAircraftCarrier extends Vehicle
{
	public ShipAircraftCarrier(String identifier, Powerplant powerplant)
	{
		super(identifier, powerplant);
	}
}
