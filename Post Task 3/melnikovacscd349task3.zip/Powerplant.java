//Andrey Melnikov

public abstract class Powerplant 
{
	private final String identifier;
	private Vehicle host;
	
	public Powerplant(String identifier)
	{
		this.identifier = identifier;
	}
	
	public String getID()
	{
		return this.identifier;
	}
	
	public void setHost(Vehicle vehicle)
	{
		if(null != this.host)
		{
			throw new RuntimeException("ERROR - Host is already set to:" + this.host.getID());
		}
		
		this.host = vehicle;
	}

	public Vehicle getHost()
	{
		if(null == this.host)
		{
			throw new RuntimeException("ERROR - Host is not yet set.");
		}
		
		return this.host;
	}
	
	public void removeHost()
	{
		if(null == this.host)
		{
			throw new RuntimeException("ERROR - Can not remove host as host is not yet set.");
		}
		
		this.host = null;
	}

	public boolean hasHost()
	{
		return null != this.host;
	}

	public abstract String generate();
}
