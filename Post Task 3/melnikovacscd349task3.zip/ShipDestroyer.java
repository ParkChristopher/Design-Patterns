//Andrey Melnikov

public class ShipDestroyer extends Vehicle
{
	public ShipDestroyer(String identifier, Powerplant powerplant) 
	{
		super(identifier, powerplant);
	}
}
