//Andrey Melnikov

public class SubmarineVirginiaClass extends Vehicle
{
	public SubmarineVirginiaClass(String identifier, Powerplant powerplant) 
	{
		super(identifier, powerplant);
	}
}
