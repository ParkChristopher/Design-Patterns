//Andrey Melnikov

public abstract class Vehicle 
{
	private final String identifier;
	private final String saltedIdentifier;
	protected Powerplant powerplant;
	
	public Vehicle(String identifier, Powerplant powerplant)
	{
		IdentifierSaltManager identifierSaltManager = IdentifierSaltManager.getInstance();
		
		this.identifier = identifier;
		this.saltedIdentifier = identifierSaltManager.getIDSalted(identifier);
		this.powerplant = powerplant;
		
		powerplant.setHost(this);
	}
	
	public String getID()
	{
		return this.identifier;
	}
	
	public String getIDSalted()
	{
		return this.saltedIdentifier;
	}
	
	public Powerplant getPowerplant()
	{
		if(null == this.powerplant)
		{
			throw new RuntimeException("no installed powerplant");
		}
		
		return this.powerplant;
	}
	
	public void removePowerplant()
	{
		if(null == this.powerplant)
		{
			throw new RuntimeException("no installed powerplant");
		}
		
		this.powerplant.removeHost();
		this.powerplant = null;
	}
	
	public void installPowerplant(Powerplant powerplant)
	{
		if(null != this.powerplant)
		{
			throw new RuntimeException("powerplant " + this.powerplant.getID() + "  already installed");
		}
		
		this.powerplant = powerplant;
		this.powerplant.setHost(this);
	}
	
	public boolean hasPowerplant()
	{
		return null != this.powerplant;
	}
	
	public void move()
	{
		if( this.powerplant != null)
		{
			System.out.println(this.getIDSalted() + ": " + this.powerplant.generate());
		}
		else
		{
			System.out.println("no powerplant");
		}
	}
}