//Andrey Melnikov

public class PowerplantGasTurbine extends Powerplant
{
	public PowerplantGasTurbine(String identifier)
	{
		super(identifier);
	}
	
	@Override
	public String generate()
	{
		return "spinning a gas turbine";
	}
}
