//Andrey Melnikov

public class AircraftFighterJet extends Vehicle
{
	public AircraftFighterJet(String identifier, Powerplant powerplant) 
	{
		super(identifier, powerplant);
	}
}
