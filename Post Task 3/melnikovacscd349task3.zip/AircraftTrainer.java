//Andrey Melnikov

public class AircraftTrainer extends Vehicle
{
	public AircraftTrainer(String identifier, Powerplant powerplant)
	{
		super(identifier, powerplant);
	}
}
