//Andrey Melnikov

public class PowerplantTurboshaft extends Powerplant
{
	public PowerplantTurboshaft(String identifier) 
	{
		super(identifier);
	}

	@Override
	public String generate() 
	{
		return "spinning a shaft";
	}
}
