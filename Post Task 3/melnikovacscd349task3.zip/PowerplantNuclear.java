//Andrey Melnikov

public class PowerplantNuclear extends Powerplant
{
	public PowerplantNuclear(String identifier)
	{
		super(identifier);
	}

	@Override
	public String generate() 
	{
		return "splitting atoms";
	}
}
