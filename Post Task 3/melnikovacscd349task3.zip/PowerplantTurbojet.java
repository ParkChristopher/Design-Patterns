//Andrey Melnikov

public class PowerplantTurbojet extends Powerplant
{
	public PowerplantTurbojet(String identifier) 
	{
		super(identifier);
	}

	@Override
	public String generate() 
	{
		return "exhausting a jet";
	}
}
