//Andrey Melnikov

public class ShipSpeedboat extends Vehicle
{
	public ShipSpeedboat(String identifier, Powerplant powerplant) 
	{
		super(identifier, powerplant);
	}
}
