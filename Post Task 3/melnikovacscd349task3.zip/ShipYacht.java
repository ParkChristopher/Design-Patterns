//Andrey Melnikov

public class ShipYacht extends Vehicle
{
	public ShipYacht(String identifier, Powerplant powerplant) 
	{
		super(identifier, powerplant);
	}
}
