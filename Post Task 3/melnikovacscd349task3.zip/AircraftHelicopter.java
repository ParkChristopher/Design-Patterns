//Andrey Melnikov

public class AircraftHelicopter extends Vehicle
{
	public AircraftHelicopter(String identifier, Powerplant powerplant) 
	{
		super(identifier, powerplant);
	}
}
