/**
 * Created by Christian Alexander on 10/15/14.
 */
public class PowerplantNuclear extends A_Powerplant {

    public PowerplantNuclear(String id)
    {
        super(id, "splitting atoms");
    }
}
