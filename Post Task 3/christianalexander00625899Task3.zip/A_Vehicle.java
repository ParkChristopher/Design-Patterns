/**
 * Created by Christian Alexander on 10/18/14.
 */
public abstract class A_Vehicle {
    private String _id, _idSalted;
    protected A_Powerplant _powerplantPrimary;

    public A_Vehicle(String id, A_Powerplant powerplant)
    {
        setID(id);
        installPowerplant(powerplant);
    }
    
    protected void setID(String id)
    {
        _id = id;
        _idSalted = IdentifierSaltManager.getInstance().getIDSalted(id);
    }

    public String getID()
    {
        return _id;
    }

    public String getIDSalted()
    {
        return _idSalted;
    }

    public A_Powerplant getPowerplant()
    {
        if(hasPowerplant())
            return _powerplantPrimary;

        throw new RuntimeException("Powerplant not found. Can not get.");
    }

    public void removePowerplant()
    {
        if(hasPowerplant()) {
            _powerplantPrimary.removeHost();
            _powerplantPrimary = null;
            return;
        }

        throw new RuntimeException("Powerplant not found. Can not remove.");
    }

    public void installPowerplant(A_Powerplant powerplant)
    {
        if(! hasPowerplant()) {
            powerplant.setHost(this);
            _powerplantPrimary = powerplant;
            return;
        }

        throw new RuntimeException(String.format("powerplant %s already installed", getPowerplant().getID()));
    }

    public boolean hasPowerplant()
    {
        return (_powerplantPrimary != null);
    }

    public void move()
    {
        if(hasPowerplant())
            System.out.printf("%s: %s\n", getIDSalted(), getPowerplant().generate());
        else
            System.out.println("no powerplant");
    }
}
