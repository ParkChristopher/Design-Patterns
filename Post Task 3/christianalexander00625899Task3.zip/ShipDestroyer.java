/**
 * Created by Christian Alexander on 10/15/14.
 */
public class ShipDestroyer extends A_Vehicle {

    public ShipDestroyer(String id, A_Powerplant powerplant)
    {
        super(id, powerplant);
    }
}
