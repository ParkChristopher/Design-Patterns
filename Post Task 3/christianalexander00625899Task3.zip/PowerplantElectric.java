/**
 * Created by Christian Alexander on 10/15/14.
 */
public class PowerplantElectric extends A_Powerplant {

    public PowerplantElectric(String id)
    {
        super(id, "generating electricity");
    }
}
