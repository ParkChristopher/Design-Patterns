/**
 * Created by Christian Alexander on 10/15/14.
 */
public class PowerplantTurboshaft extends A_Powerplant {

    public PowerplantTurboshaft(String id)
    {
        super(id, "spinning a shaft");
    }
}
