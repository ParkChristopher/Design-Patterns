/**
 * Created by Christian Alexander on 10/15/14.
 */
public class SubmarineUBoot extends A_Vehicle {
    private A_Powerplant _powerplantSecondary;

    private boolean _primaryOrSecondary;

    public SubmarineUBoot(String id, A_Powerplant powerplantPrimary, A_Powerplant powerplantSecondary)
    {
        super(id, powerplantPrimary);

        if(powerplantPrimary.getID().equals(powerplantSecondary.getID())) {
            throw new RuntimeException("Primary and secondary powerplants must not be the same powerplant object");
        }

        installPowerplantSecondary(powerplantSecondary);

        isPrimaryOrSecondary(true);
    }

    public A_Powerplant getPowerplantPrimary()
    {
        return super.getPowerplant();
    }

    public A_Powerplant getPowerplantSecondary()
    {
        if(hasPowerplantSecondary())
            return _powerplantSecondary;

        throw new RuntimeException("Powerplant not found. Can not get.");
    }

    public void isPrimaryOrSecondary(boolean primaryOrSecondary) //True = primary, False = secondary
    {
        if((primaryOrSecondary && hasPowerplantPrimary()) || (! primaryOrSecondary) && hasPowerplantSecondary())
            _primaryOrSecondary = primaryOrSecondary;
        else
            throw new RuntimeException(String.format("Error switching to powerplant %s. It is not installed.", (primaryOrSecondary)?"'primary'":"'secondary'"));
    }

    public boolean isPrimaryOrSecondary()
    {
        return _primaryOrSecondary;
    }

    public void removePowerplantPrimary()
    {
        if(hasPowerplantPrimary()) {
            _powerplantPrimary.removeHost();
            _powerplantPrimary = null;
        }
        else
            throw new RuntimeException("Primary powerplant not found. Can not remove.");
    }

    public void removePowerplantSecondary()
    {
        if(hasPowerplantSecondary()) {
            _powerplantSecondary.removeHost();
            _powerplantSecondary = null;
        }
        else
            throw new RuntimeException("Secondary powerplant not found. Can not remove.");
    }

    public boolean hasPowerplantPrimary()
    {
        return super.hasPowerplant();
    }

    public boolean hasPowerplantSecondary()
    {
        return (_powerplantSecondary != null);
    }

    public void installPowerplantPrimary(A_Powerplant powerplant)
    {
        if(hasPowerplantSecondary() && (powerplant.getID().equals(getPowerplantSecondary().getID())))
            throw new RuntimeException("Primary and Secondary powerplants must not be the same powerplant object");

        if(! hasPowerplantPrimary())
        {
            powerplant.setHost(this);
            _powerplantPrimary = powerplant;
            return;
        }

        throw new RuntimeException(String.format("powerplant %s already installed", getPowerplant().getID()));
    }

    public void installPowerplantSecondary(A_Powerplant powerplant)
    {
        if(hasPowerplantPrimary() && (powerplant.getID().equals(getPowerplantPrimary().getID())))
            throw new RuntimeException("Primary and Secondary powerplants must not be the same powerplant object");

        if(! hasPowerplantSecondary())
        {
            powerplant.setHost(this);
            _powerplantSecondary = powerplant;
        }
        else
            throw new RuntimeException(String.format("powerplant %s already installed", _powerplantSecondary.getID()));
    }

    @Override
    public void move()
    {
        if(hasPowerplant())
            if(isPrimaryOrSecondary())
                System.out.printf("%s: %s\n", getIDSalted(), getPowerplantPrimary().generate());
            else
                System.out.printf("%s: %s\n", getIDSalted(), getPowerplantSecondary().generate());
        else
            System.out.println("no powerplant");
    }

    @Override
    public A_Powerplant getPowerplant() //Gets currently active powerplant
    {
        if(isPrimaryOrSecondary())
            return getPowerplantPrimary();
        else
            return getPowerplantSecondary();
    }

    @Override
    public void removePowerplant() //Removes currently active powerplant
    {
        if(isPrimaryOrSecondary())
        {
            removePowerplantPrimary();
            selectOnlyPowerplantIfOnlyOneExists();
        }
        else
        {
            removePowerplantSecondary();
            selectOnlyPowerplantIfOnlyOneExists();
        }
    }

    @Override
    public void installPowerplant(A_Powerplant powerplant) {
        if (!hasPowerplantPrimary()) {
            installPowerplantPrimary(powerplant);
            selectOnlyPowerplantIfOnlyOneExists();
        } else if (!hasPowerplantSecondary()) {
            installPowerplantSecondary(powerplant);
            selectOnlyPowerplantIfOnlyOneExists();
        }
        else
            throw new RuntimeException("Both powerplants are installed. Can not install any more.");
    }

    @Override
    public boolean hasPowerplant()
    {
        return (hasPowerplantPrimary() || hasPowerplantSecondary());
    }

    private void selectOnlyPowerplantIfOnlyOneExists()
    {
        if(!hasPowerplantSecondary() && hasPowerplantPrimary())
            isPrimaryOrSecondary(true);
        if(!hasPowerplantPrimary() && hasPowerplantSecondary())
            isPrimaryOrSecondary(false);
    }
}