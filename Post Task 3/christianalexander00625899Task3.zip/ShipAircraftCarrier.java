/**
 * Created by Christian Alexander on 10/15/14.
 */
public class ShipAircraftCarrier extends A_Vehicle {

    public ShipAircraftCarrier(String id, A_Powerplant powerplant)
    {
        super(id, powerplant);
    }
}
