/**
 * Created by Christian Alexander on 10/15/14.
 */
public class AircraftTrainer extends A_Vehicle {

    public AircraftTrainer(String id, A_Powerplant powerplant)
    {
        super(id, powerplant);
    }
}
