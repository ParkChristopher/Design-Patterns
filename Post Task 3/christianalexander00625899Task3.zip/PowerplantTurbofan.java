/**
 * Created by Christian Alexander on 10/15/14.
 */
public class PowerplantTurbofan extends A_Powerplant {

    public PowerplantTurbofan(String id)
    {
        super(id, "bypassing lots of air");
    }
}
