/**
 * Created by Christian Alexander on 10/15/14.
 */
public class AircraftFighterJet extends A_Vehicle {

    public AircraftFighterJet(String id, A_Powerplant powerplant)
    {
        super(id, powerplant);
    }
}
