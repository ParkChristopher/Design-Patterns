/**
 * Created by Christian Alexander on 10/15/14.
 */
public class PowerplantGasTurbine extends A_Powerplant {

    public PowerplantGasTurbine(String id)
    {
        super(id, "spinning a gas turbine");
    }
}
