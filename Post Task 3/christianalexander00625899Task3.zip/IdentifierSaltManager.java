/**
 * Created by Christian Alexander on 10/15/14.
 */
public class IdentifierSaltManager {
    private static IdentifierSaltManager _saltManager = null;
    private int _currentSalt = 1;

    private IdentifierSaltManager() {}

    public static IdentifierSaltManager getInstance()
    {
        if(_saltManager == null)
            _saltManager = new IdentifierSaltManager();
        return _saltManager;
    }

    public String getIDSalted(String id)
    {
        return id + '#' + getSaltNext();
    }

    private int getSaltNext()
    {
        return _currentSalt++;
    }
}
