/**
 * Created by Christian Alexander on 10/15/14.
 */
public class ShipSpeedboat extends A_Vehicle {

    public ShipSpeedboat(String id, A_Powerplant powerplant)
    {
        super(id, powerplant);
    }
}
