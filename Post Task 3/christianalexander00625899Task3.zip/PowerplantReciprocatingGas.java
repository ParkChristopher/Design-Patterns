/**
 * Created by Christian Alexander on 10/15/14.
 */
public class PowerplantReciprocatingGas extends A_Powerplant {

    public PowerplantReciprocatingGas(String id)
    {
        super(id, "vroom vroom!");
    }
}
