/**
 * Created by Christian Alexander on 10/15/14.
 */
public class AircraftHelicopter extends A_Vehicle {

    public AircraftHelicopter(String id, A_Powerplant powerplant)
    {
        super(id, powerplant);
    }
}
