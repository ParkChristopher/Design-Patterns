/**
 * Created by Christian Alexander on 10/18/14.
 */
public abstract class A_Powerplant {
    private String _id;
    private A_Vehicle _host;
    private String _generateText;

    public A_Powerplant(String id, String generateText)
    {
        _id = id;
        _generateText = generateText;
    }

    public String getID()
    {
        return _id;
    }

    public void setHost(A_Vehicle host)
    {
        if(_host == null) {
            _host = host;
            return;
        }

        throw new RuntimeException(String.format("Host already set. (Currently %s)", _host.getIDSalted()));
    }

    public A_Vehicle getHost()
    {
        if(_host != null)
            return _host;

        throw new RuntimeException("No host set.");
    }

    public void removeHost()
    {
        if(_host != null) {
            _host = null;
            return;
        }

        throw new RuntimeException("No host set. Can not remove.");
    }

    public boolean hasHost()
    {
        return (_host != null);
    }

    public String generate()
    {
        return _generateText;
    }
}
