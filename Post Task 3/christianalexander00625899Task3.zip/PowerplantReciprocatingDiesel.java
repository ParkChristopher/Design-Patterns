/**
 * Created by Christian Alexander on 10/15/14.
 */
public class PowerplantReciprocatingDiesel extends A_Powerplant {

    public PowerplantReciprocatingDiesel(String id)
    {
        super(id, "chattering away");
    }
}
