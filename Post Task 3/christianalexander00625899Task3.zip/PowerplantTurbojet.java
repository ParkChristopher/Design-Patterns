/**
 * Created by Christian Alexander on 10/15/14.
 */
public class PowerplantTurbojet extends A_Powerplant {

    public PowerplantTurbojet(String id)
    {
        super(id, "exhausting a jet");
    }
}
